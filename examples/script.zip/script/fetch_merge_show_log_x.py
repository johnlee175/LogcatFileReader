#!/usr/bin/env python

import urllib
import urllib2
import re
import os
import sys

_VERSION = '1.0.0'
_BASE_URL = 'http://cq01-rdqa-dev003.cq01.baidu.com:8088/logs/prod/view/sdk/'


# change this method for your custom
def fetch_urls(uid, date, package):
    result_urls = []
    href_pattern = re.compile(".*?<a\shref=\"(" + package +
                              "\.logcat\.dump\.(\d\d\d\d\d\d\d\d\d\d\d\d\d\d)\.log.*?)\">" +
                              package + "\.logcat\.dump\.\d+.+?")
    req_url = _BASE_URL + uid
    request = urllib2.Request(req_url)
    resp = urllib2.urlopen(request, timeout=30)
    for line in resp.read().splitlines():
        match = href_pattern.match(line)
        if match:
            if int(match.group(2)) >= int(date):
                result_urls.append(req_url + '/' + match.group(1))
    return result_urls


def download(urls, logs_folder):
    if not os.path.exists(logs_folder):
        os.makedirs(logs_folder)
    for url in urls:
        print 'downloading ' + url
        filename = url[(url.rindex('/') + 1):]
        log_path = os.path.join(logs_folder, filename)
        urllib.urlretrieve(url, log_path)


def unpack(logs_folder):
    print 'unzip all log files ...'
    for parent, dir_names, file_names in os.walk(logs_folder):
        for file_name in file_names:
            full_path = os.path.join(parent, file_name)
            file_base, file_ext = os.path.splitext(full_path)
            if file_ext == '.zip':
                if os.path.exists(file_base):
                    os.remove(file_base)
                unzip(full_path, logs_folder, True)


def unzip(zip_path, extract_dir, delete_zip_on_extracted):
    import zipfile
    # comment following code is because of the unix file permissions lost
    # zip_files = zipfile.ZipFile(zip_path, 'r')
    # zip_files.extractall(extract_dir)
    # zip_files.close()
    if not zipfile.is_zipfile(zip_path):
        print "%s is not a zip file" % zip_path
        exit(0)
    z = zipfile.ZipFile(zip_path)
    try:
        for info in z.infolist():
            name = info.filename
            if '..' in name:
                continue
            if name.startswith('/'):
                name = name[1:]
            target = os.path.join(extract_dir, *name.split('/'))
            if not target:
                continue
            if name.endswith('/'):  # directory
                dirname = os.path.dirname(target)
                if not os.path.isdir(dirname):
                    os.makedirs(dirname)
            else:  # file
                dirname = os.path.dirname(target)
                if not os.path.isdir(dirname):
                    os.makedirs(dirname)
                data = z.read(info.filename)
                f = open(target, 'wb')
                try:
                    f.write(data)
                finally:
                    f.close()
                    del data
            unix_attributes = info.external_attr >> 16
            if unix_attributes:
                os.chmod(target, unix_attributes)
    finally:
        z.close()
        if delete_zip_on_extracted:
            os.remove(zip_path)


# logcat.dump.20160503082219.log
pattern = re.compile("^logcat\.dump\.(\d\d\d\d\d\d\d\d\d\d\d\d\d\d)\.log$")


def merge_files(logs_folder):
    print 'merge all log files ...'
    file_list = []
    for parent, dir_names, file_names in os.walk(logs_folder):
        for file_name in file_names:
            if pattern.match(file_name):
                file_list.append(file_name)
    file_list.sort(cmp=compare_file_index)
    output_path = os.path.join(logs_folder, file_list[0])
    output_fd = open(output_path, mode='a')
    for log_file in file_list[1:]:
        log_path = os.path.join(logs_folder, log_file)
        input_fd = open(log_path)
        data = input_fd.read()
        output_fd.write(data)
        output_fd.flush()
        input_fd.close()
        del data
        os.remove(log_path)
    output_fd.close()
    return output_path


def compare_file_index(a, b):
    a_num = int(pattern.match(a).group(1))
    b_num = int(pattern.match(b).group(1))
    if a_num > b_num:
        return 1
    elif a_num < b_num:
        return -1
    else:
        return 0


def show_log(log_path):
    if os.path.exists('LogcatFileReader-1.0.0.jar'):
        cmd = 'java -jar LogcatFileReader-1.0.0.jar ' + log_path + ' threadtime'
    else:
        cmd = 'vim ' + log_path
    print 'exec ' + cmd
    os.system(cmd)


def parse_opt(argv):
    import optparse
    usage = 'Usage: %prog [[options] [value]]'
    desc = """Example 1: %prog -u 2060900675 -p com.baidu.durobot.launcher -d 20160420153000
    \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t
    Example 2: %prog -p com.baidu.durobot.launcher -a robokit -l ../../logs/"""
    parser = optparse.OptionParser(usage=usage, description=desc)
    parser.add_option('-v', dest='version', action='store_true', help='show the current version')
    parser.add_option('-u', dest='user_id', type='string', help="special the device user id",
                      default=' ', metavar='USER_ID')
    parser.add_option('-p', dest='package', type='string',
                      help="special the app package name[default=com.baidu.durobot.launcher]",
                      default='com.baidu.durobot.launcher', metavar='PACKAGE_NAME')
    parser.add_option('-l', dest='log_dir', type='string',
                      help="special the directory which store logs",
                      default=' ', metavar='LOG_DIR')
    parser.add_option('-d', dest='date', type='string',
                      help='which day of log do you want to see[default=today]',
                      default=get_curr_date(), metavar='DATE_STRING')
    options, categories = parser.parse_args(argv[1:])

    def print_help():
        parser.print_help()

    return options.version, options.user_id, options.date, options.package, \
        options.log_dir, print_help


def get_curr_date():
    import time
    return time.strftime('%Y%m%d%H%M%S', time.localtime(time.time()))


def is_valid_date(date_str):
    import time
    try:
        time.strptime(date_str, '%Y%m%d%H%M%S')
        return True
    except ValueError, e:
        print e
        return False


def remove_dir(top_dir):
    if os.path.exists(top_dir):
        for root, dirs, files in os.walk(top_dir, topdown=False):
            for name in files:
                os.remove(os.path.join(root, name))
            for name in dirs:
                os.rmdir(os.path.join(root, name))
        os.rmdir(top_dir)


def sys_std_err(msg):
    sys.stderr.write('\033[91m WARNING: ' + msg + ' \033[0m\n\n')


def main(argv):
    logs_folder = 'logs'
    version, user_id, date, package, log_dir, print_help = parse_opt(argv)
    if version:
        print 'The Current Version: ' + _VERSION
        return
    if not package or len(package.strip()) == 0:
        sys_std_err('The package name provided by -p {PACKAGE_NAME} is invalid, '
                    'like com.baidu.durobot.launcher')
        print_help()
        return
    if not log_dir or len(log_dir.strip()) == 0:
        if not user_id or len(user_id.strip()) == 0:
            sys_std_err('User id required, please with -u {USER_ID}')
            print_help()
            return
        if not is_valid_date(date):
            sys_std_err('The date string provided by -d {DATE_STRING} is invalid, '
                        'accurate to seconds, like 20160101053000')
            print_help()
            return
        remove_dir(logs_folder)
        url_list = fetch_urls(user_id, date, package)
        if not url_list:
            sys_std_err('No new log files be matched from remote site')
            print_help()
            return
        download(url_list, logs_folder)
    else:
        logs_folder = log_dir
    unpack(logs_folder)
    show_log(merge_files(logs_folder))


if __name__ == '__main__':
    main(sys.argv)
